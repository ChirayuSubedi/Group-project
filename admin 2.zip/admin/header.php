<!DOCTYPE html>
<html lang="en" dir="ltr">


<!-- Mirrored from learnplus-bootstrap.frontendmatter.com/fixed-instructor-dashboard.html by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 14 Dec 2018 08:16:50 GMT -->
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Title to be edit</title>

    <!-- Prevent the demo from appearing in search engines (REMOVE THIS) -->
    <meta name="robots" content="noindex">

    <!-- Perfect Scrollbar -->
    <link type="text/css" href="/admin/assets/vendor/perfect-scrollbar.css" rel="stylesheet">

    <!-- Material Design Icons -->
    <link type="text/css" href="/admin/assets/css/material-icons.css" rel="stylesheet">
    <link type="text/css" href="/admin/assets/css/material-icons.rtl.css" rel="stylesheet">

    <!-- Font Awesome Icons -->
    <link type="text/css" href="/admin/assets/css/fontawesome.css" rel="stylesheet">
    <link type="text/css" href="/admin/assets/css/fontawesome.rtl.css" rel="stylesheet">

    <!-- App CSS -->
    <link type="text/css" href="/admin/assets/css/app.css" rel="stylesheet">
    <link type="text/css" href="/admin/assets/css/app.rtl.css" rel="stylesheet">









</head>

<body class=" fixed-layout">










    <div class="preloader">
        <div class="sk-double-bounce">
            <div class="sk-child sk-double-bounce1"></div>
            <div class="sk-child sk-double-bounce2"></div>
        </div>
    </div>

    <!-- Header Layout -->
    <div class="mdk-header-layout js-mdk-header-layout">

        <!-- Header -->

        <div id="header" class="mdk-header bg-dark js-mdk-header m-0" data-fixed data-effects="waterfall">
            <div class="mdk-header__content">

                <!-- Navbar -->
                <nav id="default-navbar" class="navbar navbar-expand navbar-dark bg-primary m-0">
                    <div class="container">
                        <!-- Toggle sidebar -->
                        <button class="navbar-toggler d-block" data-toggle="sidebar" type="button">
                            <span class="material-icons">menu</span>
                        </button>

                        <!-- Brand -->
                        <a href="nami-student-browse-course.php" class="navbar-brand">
                            <img src="assets/images/logo/white.svg" class="mr-2" alt="LearnPlus" />
                            <span class="d-none d-xs-md-block">Title to be edit</span>
                        </a>

                     

                        <!-- Search -->
                        <form class="search-form d-none d-md-flex">
                            <input type="text" class="form-control" placeholder="Search">
                            <button class="btn" type="button"><i class="material-icons font-size-24pt">search</i></button>
                        </form>
                        <!-- // END Search -->

                        <div class="flex"></div>

                        <!-- Menu -->
                        <ul class="nav navbar-nav flex-nowrap d-none d-lg-flex">
                            <li class="nav-item">
                                <a class="nav-link" href="fixed-instructor-forum.html">Forum</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="fixed-instructor-forum.html">Get Help</a>
                            </li>

                        </ul>

                        <!-- Menu -->
                        <ul class="nav navbar-nav flex-nowrap">




                            <!-- Notifications dropdown -->
                            <li class="nav-item dropdown dropdown-notifications dropdown-menu-sm-full">
                                <button class="nav-link btn-flush dropdown-toggle" type="button" data-toggle="dropdown" data-dropdown-disable-document-scroll data-caret="false">
                                    <i class="material-icons">notifications</i>
                                    <span class="badge badge-notifications badge-danger">2</span>
                                </button>
                                <div class="dropdown-menu dropdown-menu-right">
                                    <div data-perfect-scrollbar class="position-relative">
                                        <div class="dropdown-header"><strong>Messages</strong></div>
                                        <div class="list-group list-group-flush mb-0">

                                            <a href="fixed-instructor-messages.html" class="list-group-item list-group-item-action unread">
                                                <span class="d-flex align-items-center mb-1">
                                                    <small class="text-muted">5 minutes ago</small>

                                                    <span class="ml-auto unread-indicator bg-primary"></span>

                                                </span>
                                                <span class="d-flex">
                                                    <span class="avatar avatar-xs mr-2">
                                                        <img src="assets/images/people/110/woman-5.jpg" alt="people" class="avatar-img rounded-circle">
                                                    </span>
                                                    <span class="flex d-flex flex-column">
                                                        <strong>Michelle</strong>
                                                        <span class="text-black-70">Clients loved the new design.</span>
                                                    </span>
                                                </span>
                                            </a>

                                            <a href="fixed-instructor-messages.html" class="list-group-item list-group-item-action unread">
                                                <span class="d-flex align-items-center mb-1">
                                                    <small class="text-muted">5 minutes ago</small>

                                                    <span class="ml-auto unread-indicator bg-primary"></span>

                                                </span>
                                                <span class="d-flex">
                                                    <span class="avatar avatar-xs mr-2">
                                                        <img src="assets/images/people/110/woman-5.jpg" alt="people" class="avatar-img rounded-circle">
                                                    </span>
                                                    <span class="flex d-flex flex-column">
                                                        <strong>Michelle</strong>
                                                        <span class="text-black-70">🔥 Superb job..</span>
                                                    </span>
                                                </span>
                                            </a>

                                        </div>

                                        <div class="dropdown-header"><strong>System notifications</strong></div>
                                        <div class="list-group list-group-flush mb-0">

                                            <a href="fixed-instructor-messages.html" class="list-group-item list-group-item-action border-left-3 border-left-danger">
                                                <span class="d-flex align-items-center mb-1">
                                                    <small class="text-muted">3 minutes ago</small>

                                                </span>
                                                <span class="d-flex">
                                                    <span class="avatar avatar-xs mr-2">
                                                        <span class="avatar-title rounded-circle bg-light">
                                                            <i class="material-icons font-size-16pt text-danger">account_circle</i>
                                                        </span>
                                                    </span>
                                                    <span class="flex d-flex flex-column">

                                                        <span class="text-black-70">Your profile information has not been synced correctly.</span>
                                                    </span>
                                                </span>
                                            </a>

                                            <a href="fixed-instructor-messages.html" class="list-group-item list-group-item-action">
                                                <span class="d-flex align-items-center mb-1">
                                                    <small class="text-muted">5 hours ago</small>

                                                </span>
                                                <span class="d-flex">
                                                    <span class="avatar avatar-xs mr-2">
                                                        <span class="avatar-title rounded-circle bg-light">
                                                            <i class="material-icons font-size-16pt text-success">group_add</i>
                                                        </span>
                                                    </span>
                                                    <span class="flex d-flex flex-column">
                                                        <strong>Adrian. D</strong>
                                                        <span class="text-black-70">Wants to join your private group.</span>
                                                    </span>
                                                </span>
                                            </a>

                                            <a href="fixed-instructor-messages.html" class="list-group-item list-group-item-action">
                                                <span class="d-flex align-items-center mb-1">
                                                    <small class="text-muted">1 day ago</small>

                                                </span>
                                                <span class="d-flex">
                                                    <span class="avatar avatar-xs mr-2">
                                                        <span class="avatar-title rounded-circle bg-light">
                                                            <i class="material-icons font-size-16pt text-warning">storage</i>
                                                        </span>
                                                    </span>
                                                    <span class="flex d-flex flex-column">

                                                        <span class="text-black-70">Your deploy was successful.</span>
                                                    </span>
                                                </span>
                                            </a>

                                        </div>
                                    </div>
                                </div>
                            </li>
                            <!-- // END Notifications dropdown -->

                            <!-- User dropdown -->
                            <li class="nav-item dropdown ml-1 ml-md-3">
                                <a class="nav-link active dropdown-toggle" data-toggle="dropdown" href="#" role="button"><img src="assets/images/people/50/guy-6.jpg" alt="Avatar" class="rounded-circle" width="40"></a>
                                <div class="dropdown-menu dropdown-menu-right">
                                    <a class="dropdown-item" href="fixed-instructor-account-edit.html">
                                        <i class="material-icons">edit</i> Edit Account
                                    </a>
                                    <a class="dropdown-item" href="fixed-instructor-profile.html">
                                        <i class="material-icons">person</i> Public Profile
                                    </a>
                                    <a class="dropdown-item" href="guest-login.html">
                                        <i class="material-icons">lock</i> Logout
                                    </a>
                                </div>
                            </li>
                            <!-- // END User dropdown -->
                        </ul>
                    </div>
                </nav>
                <!-- // END Navbar -->

            </div>
        </div>

        <!-- // END Header -->

        <!-- Header Layout Content -->
        <div class="mdk-header-layout__content d-flex flex-column">

            <div class="page__header">
                <div class="navbar bg-dark navbar-dark navbar-expand-sm d-none2 d-md-flex2">
                    <div class="container">

                        <div class="navbar-collapse collapse" id="navbarsExample03">
                            <ul class="nav navbar-nav">
                                <li class="nav-item dropdown">
                                    <a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown">Student</a>
                                    <div class="dropdown-menu">
                                        <a class="dropdown-item" href="fixed-student-dashboard.html">Dashboard</a>
                                        <a class="dropdown-item" href="fixed-student-browse-courses.html">Browse Courses</a>
                                        <a class="dropdown-item" href="fixed-student-view-course.html">View Course</a>
                                        <a class="dropdown-item" href="fixed-student-take-course.html">Take Course</a>
                                        <a class="dropdown-item" href="fixed-student-take-quiz.html">Take a Quiz</a>
                                        <a class="dropdown-item" href="fixed-student-quiz-results.html">Quiz Results</a>
                                        <a class="dropdown-item" href="fixed-student-my-courses.html">My Courses</a>
                                        <a class="dropdown-item" href="fixed-student-billing.html">Billing</a>
                                        <a class="dropdown-item" href="fixed-student-pay.html">Payment</a>
                                    </div>
                                </li>
                                <li class="nav-item dropdown active">
                                    <a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown">Instructor</a>
                                    <div class="dropdown-menu">
                                        <a class="dropdown-item active" href="fixed-instructor-dashboard.html">Dashboard</a>
                                        <a class="dropdown-item" href="fixed-instructor-courses.html">Course Manager</a>
                                        <a class="dropdown-item" href="fixed-instructor-quizzes.html">Quiz Manager</a>
                                        <a class="dropdown-item" href="fixed-instructor-profile.html">Public Profile</a>
                                        <a class="dropdown-item" href="fixed-instructor-earnings.html">Earnings</a>
                                        <a class="dropdown-item" href="fixed-instructor-statement.html">Statement</a>
                                    </div>
                                </li>
                                <li class="nav-item dropdown">
                                    <a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown">Account</a>
                                    <div class="dropdown-menu">
                                        <a class="dropdown-item" href="fixed-instructor-account-edit.html">Edit Account</a>
                                        <a class="dropdown-item" href="fixed-instructor-messages.html">Messages</a>
                                        <a class="dropdown-item" href="fixed-instructor-invoice.html">Invoice</a>
                                        <a class="dropdown-item" href="guest-login.html">Logout</a>
                                    </div>
                                </li>
                                <li class="nav-item dropdown">
                                    <a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown">Components</a>
                                    <div class="dropdown-menu">
                                        <a class="dropdown-item" href="fixed-ui-avatars.html">Avatars</a>
                                        <a class="dropdown-item" href="fixed-ui-forms.html">Forms</a>
                                        <a class="dropdown-item" href="fixed-ui-loaders.html">Loaders</a>
                                        <a class="dropdown-item" href="fixed-ui-tables.html">Tables</a>
                                        <a class="dropdown-item" href="fixed-ui-cards.html">Cards</a>
                                        <a class="dropdown-item" href="fixed-ui-tabs.html">Tabs</a>
                                        <a class="dropdown-item" href="fixed-ui-icons.html">Icons</a>
                                        <a class="dropdown-item" href="fixed-ui-buttons.html">Buttons</a>
                                        <a class="dropdown-item" href="fixed-ui-alerts.html">Alerts</a>
                                        <a class="dropdown-item" href="fixed-ui-badges.html">Badges</a>
                                        <!-- <a class="dropdown-item" href="fixed-ui-modals.html">- Modals</a> -->
                                        <a class="dropdown-item" href="fixed-ui-progress.html">Progress</a>
                                    </div>
                                </li>
                                <li class="nav-item dropdown">
                                    <a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown">Plugins</a>
                                    <div class="dropdown-menu">
                                        <a class="dropdown-item" href="fixed-ui-charts.html">Charts</a>
                                        <a class="dropdown-item" href="fixed-ui-drag.html">Drag &amp; Drop</a>
                                        <a class="dropdown-item" href="fixed-ui-calendar.html">Calendar</a>
                                        <a class="dropdown-item" href="fixed-ui-nestable.html">Nestable</a>
                                        <a class="dropdown-item" href="fixed-ui-tree.html">Tree</a>
                                        <a class="dropdown-item" href="fixed-ui-maps-vector.html">Vector Maps</a>
                                        <a class="dropdown-item" href="fixed-ui-sweet-alert.html">Sweet Alert</a>
                                    </div>
                                </li>
                                <li class="nav-item dropdown">
                                    <a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown">Layouts</a>
                                    <div class="dropdown-menu">
                                        <a class="dropdown-item" href="instructor-dashboard.html">Fluid</a>
                                        <a class="dropdown-item active" href="fixed-instructor-dashboard.html">Fixed</a>
                                    </div>
                                </li>
                            </ul>
                        </div>

                        <button class="navbar-toggler" data-toggle="collapse" data-target="#navbarsExample03" type="button">
                            <span class="material-icons">menu</span>
                        </button>

                    </div>
                </div>
            </div>


                








    <!-- App Settings FAB -->
    
    <!-- jQuery -->
    <script src="assets/vendor/jquery.min.js"></script>

    <!-- Bootstrap -->
    <script src="assets/vendor/popper.min.js"></script>
    <script src="assets/vendor/bootstrap.min.js"></script>

    <!-- Perfect Scrollbar -->
    <script src="assets/vendor/perfect-scrollbar.min.js"></script>

    <!-- MDK -->
    <script src="assets/vendor/dom-factory.js"></script>
    <script src="assets/vendor/material-design-kit.js"></script>

    <!-- App JS -->
    <script src="assets/js/app.js"></script>

    <!-- Highlight.js -->
    <script src="assets/js/hljs.js"></script>

    <!-- App Settings (safe to remove) -->
    <script src="assets/js/app-settings.js"></script>






    <!-- Global Settings -->
    <script src="assets/js/settings.js"></script>

    <!-- Moment.js -->
    <script src="assets/vendor/moment.min.js"></script>
    <script src="assets/vendor/moment-range.min.js"></script>

    <!-- Chart.js -->
    <script src="assets/vendor/Chart.min.js"></script>

    <!-- UI Charts Page JS -->
    <script src="assets/js/chartjs-rounded-bar.js"></script>
    <script src="assets/js/chartjs.js"></script>

    <!-- Chart.js Samples -->
    <script>
        (function() {
            'use strict';

            Charts.init()

            var earnings = []

            // Create a date range for the last 7 days
            var start = moment().subtract(7, 'days').format('YYYY-MM-DD') // 7 days ago
            var end = moment().format('YYYY-MM-DD') // today
            var range = moment.range(start, end)

            // Create the earnings graph data
            // Iterate the date range and assign a random ($) earnings value for each day
            range.by('days', function(moment) {
                earnings.push({
                    y: Math.floor(Math.random() * 300) + 10,
                    x: moment.toDate()
                })
            })

            var Earnings = function(id, type = 'roundedBar', options = {}) {
                options = Chart.helpers.merge({
                    barRoundness: 1.2,
                    scales: {
                        yAxes: [{
                            ticks: {
                                callback: function(a) {
                                    if (!(a % 10))
                                        return "$" + a
                                }
                            }
                        }],
                        xAxes: [{
                            offset: true,
                            ticks: {
                                padding: 10
                            },
                            maxBarThickness: 20,
                            gridLines: {
                                display: false
                            },
                            type: 'time',
                            time: {
                                unit: 'day'
                            }
                        }]
                    },
                    tooltips: {
                        callbacks: {
                            label: function(a, e) {
                                var t = e.datasets[a.datasetIndex].label || "",
                                    o = a.yLabel,
                                    r = "";
                                return 1 < e.datasets.length && (r += '<span class="popover-body-label mr-auto">' + t + "</span>"), r += '<span class="popover-body-value">$' + o + "</span>"
                            }
                        }
                    }
                }, options)

                var data = {
                    datasets: [{
                        label: "Earnings",
                        data: earnings
                    }]
                }

                Charts.create(id, type, options, data)
            }

            // Create Chart
            Earnings('#earningsChart')

        })()
    </script>

    <!-- List.js -->
    <script src="assets/vendor/list.min.js"></script>
    <script src="assets/js/list.js"></script>

</body>


<!-- Mirrored from learnplus-bootstrap.frontendmatter.com/fixed-instructor-dashboard.html by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 14 Dec 2018 08:16:50 GMT -->
</html>
